#Polecenie git pull najpierw uruchamia polecenie git fetch,
#które służy do pobrania zawartości z określonego repozytorium zdalnego.
#Następnie wykonywane jest polecenie git merge, aby scalić referencje i końcówki gałęzi zawartości zdalnej,
#tworząc nowy lokalny commit scalenia.