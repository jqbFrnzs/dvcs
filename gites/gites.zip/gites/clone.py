#Clone repo located at <repo> onto local machine. Original repo can be
#located on the local filesystem or on a remote machine via HTTP or SSH

def clone(directory):
    


