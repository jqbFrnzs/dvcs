#Show difference between working directory and last commit.

