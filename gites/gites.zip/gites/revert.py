#Create new commit that undoes all of the changes made in
#<commit>, then apply it to the current branch.

