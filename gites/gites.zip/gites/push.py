#The git push command is used to upload local repository content to a remote repository.
#Pushing is how you transfer commits from your local repository to a remote repo.
#It's the counterpart to git fetch

