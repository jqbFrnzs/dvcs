#Stage all changes in <directory> for the next commit.
#Replace <directory> with a <file> to change a specific file